"""Image generation: DALL-E or fallback (optional)."""
import os
import uuid
from config import Config

def generate_agri_image(prompt: str) -> str:
    """
    Generate an agriculture-related image. Returns URL path (e.g. uploads/images/xxx.png) or empty.
    """
    if not Config.OPENAI_API_KEY or not prompt:
        return ""
    safe_prompt = (prompt[:500] + " agriculture farming crop field") if len(prompt) > 500 else prompt + " agriculture farming"
    try:
        from openai import OpenAI
        client = OpenAI(api_key=Config.OPENAI_API_KEY)
        r = client.images.generate(model="dall-e-2", prompt=safe_prompt, size="256x256", n=1)
        url = r.data[0].url
        # Download to uploads/images and return local path
        import requests
        os.makedirs(os.path.join(Config.UPLOAD_FOLDER, "images"), exist_ok=True)
        fname = f"{uuid.uuid4().hex}.png"
        path = os.path.join(Config.UPLOAD_FOLDER, "images", fname)
        resp = requests.get(url, timeout=15)
        if resp.ok:
            with open(path, "wb") as f:
                f.write(resp.content)
            return os.path.join("uploads", "images", fname).replace("\\", "/")
    except Exception as e:
        print("Image gen error:", e)
    return ""
