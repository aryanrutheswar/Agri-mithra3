// Form submission
document.getElementById('applyForm').addEventListener('submit', function(e){
    e.preventDefault();
    alert('Your application has been submitted successfully!');
});