"""Configuration for Agri Mitra backend."""
import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    SECRET_KEY = os.getenv("SECRET_KEY", "agri-mitra-secret-key-change-in-production")
    
    # MySQL
    MYSQL_HOST = os.getenv("MYSQL_HOST", "localhost")
    MYSQL_USER = os.getenv("MYSQL_USER", "root")
    MYSQL_PASSWORD = os.getenv("MYSQL_PASSWORD", "")
    MYSQL_DATABASE = os.getenv("MYSQL_DATABASE", "agri_mitra")
    MYSQL_PORT = int(os.getenv("MYSQL_PORT", "3306"))
    
    # OTP (demo: 1234 for any phone)
    OTP_DEMO = os.getenv("OTP_DEMO", "1234")
    OTP_EXPIRE_MINUTES = 10
    
    # APIs (set in .env for production)
    OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
    GOOGLE_APPLICATION_CREDENTIALS = os.getenv("GOOGLE_APPLICATION_CREDENTIALS", "")
    GOOGLE_TRANSLATE_API_KEY = os.getenv("GOOGLE_TRANSLATE_API_KEY", "")  # or use ADC
    AZURE_SPEECH_KEY = os.getenv("AZURE_SPEECH_KEY", "")
    AZURE_SPEECH_REGION = os.getenv("AZURE_SPEECH_REGION", "")
    GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
    
    # Use OpenAI (openai) or Gemini (gemini) for chat
    AI_PROVIDER = os.getenv("AI_PROVIDER", "openai")
    
    # TTS: google | azure | browser (browser = no server TTS)
    TTS_PROVIDER = os.getenv("TTS_PROVIDER", "browser")
    
    # Upload folder for audio and images
    UPLOAD_FOLDER = os.path.join(os.path.dirname(__file__), "uploads")
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16 MB
