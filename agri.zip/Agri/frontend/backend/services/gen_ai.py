"""Gen AI: OpenAI or Gemini for agriculture Q&A."""
from config import Config

AGRICULTURE_SYSTEM_PROMPT = """You are Agri Mitra, a friendly and expert AI agriculture assistant. You help farmers with:
- Crop selection, sowing, and harvesting advice
- Pest and disease identification and remedies
- Soil and fertilizer guidance
- Weather impact on farming
- Organic and sustainable practices
- Government schemes and market tips
Answer in a clear, practical, and supportive way. Keep answers concise but helpful. If the user's question is not about agriculture, politely steer back to farming topics or give a brief answer."""

def get_agri_response(user_text: str, language_hint: str = "en") -> str:
    """Get agriculture-focused response from OpenAI or Gemini."""
    provider = (Config.AI_PROVIDER or "openai").lower()
    if provider == "gemini" and Config.GEMINI_API_KEY:
        return _gemini_response(user_text)
    if Config.OPENAI_API_KEY:
        return _openai_response(user_text)
    # Fallback: no API key
    return "I'm your Agri Mitra assistant. To get full AI answers, please set OPENAI_API_KEY or GEMINI_API_KEY in the server environment. For now: For crop advice, consider soil type and local weather. For pests, try neem-based solutions first."

def _openai_response(user_text: str) -> str:
    try:
        from openai import OpenAI
        client = OpenAI(api_key=Config.OPENAI_API_KEY)
        r = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": AGRICULTURE_SYSTEM_PROMPT},
                {"role": "user", "content": user_text},
            ],
            max_tokens=500,
        )
        return (r.choices[0].message.content or "").strip()
    except Exception as e:
        return f"Sorry, I couldn't process that right now. ({str(e)})"

def _gemini_response(user_text: str) -> str:
    try:
        import google.generativeai as genai
        genai.configure(api_key=Config.GEMINI_API_KEY)
        model = genai.GenerativeModel("gemini-pro")
        r = model.generate_content(
            AGRICULTURE_SYSTEM_PROMPT + "\n\nUser question: " + user_text,
            generation_config=genai.types.GenerationConfig(max_output_tokens=500),
        )
        return (r.text or "").strip()
    except Exception as e:
        return f"Sorry, I couldn't process that right now. ({str(e)})"
