# Agri-Mithra Backend with Feature Flags

A Flask-based backend for agricultural management with built-in feature flag system.

## Features

✅ **Feature Flag System** - Toggle features on/off without code changes
✅ **User Management** - Farmer registration and profiles
✅ **Crop Tracking** - Monitor crops and planting schedules
✅ **Weather Data** - Store and retrieve weather information
✅ **Market Prices** - Track crop prices across markets
✅ **AI Recommendations** - Crop recommendation system (feature-flagged)

## Quick Start

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Set Up Environment
```bash
cp .env.example .env
# Edit .env with your configuration
```

### 3. Run the Application
```bash
python app.py
```

The API will be available at `http://localhost:5000`

## Feature Flags

Feature flags allow you to enable/disable features without changing code.

### Default Feature Flags
- `weather_api` - Weather API integration (enabled)
- `crop_recommendations` - AI crop recommendations (enabled)
- `market_prices` - Market price tracking (enabled)
- `soil_analysis` - Soil analysis feature (disabled)
- `pest_detection` - Pest detection AI (disabled)
- `irrigation_scheduler` - Irrigation scheduling (enabled)
- `community_forum` - Farmer community forum (disabled)
- `government_schemes` - Government schemes info (enabled)

### Managing Feature Flags

**Get all feature flags:**
```bash
GET /api/feature-flags
```

**Check specific flag:**
```bash
GET /api/feature-flags/weather_api
```

**Toggle a flag:**
```bash
POST /api/feature-flags/weather_api/toggle
```

**Create new flag:**
```bash
POST /api/feature-flags
Content-Type: application/json

{
  "name": "new_feature",
  "enabled": false,
  "description": "Description of the feature"
}
```

## API Endpoints

### Users
- `GET /api/users` - List all users
- `GET /api/users/:id` - Get user details
- `POST /api/users` - Create new user
- `PUT /api/users/:id` - Update user

**Example - Create User:**
```json
POST /api/users
{
  "name": "Ravi Kumar",
  "email": "ravi@example.com",
  "phone": "+91-9876543210",
  "location": "Guntur, AP",
  "farm_size": 5.5
}
```

### Crops
- `GET /api/crops` - List all crops
- `GET /api/crops?user_id=1` - Get crops for specific user
- `GET /api/crops/:id` - Get crop details
- `POST /api/crops` - Create crop record
- `PUT /api/crops/:id` - Update crop

**Example - Create Crop:**
```json
POST /api/crops
{
  "user_id": 1,
  "crop_name": "Rice",
  "variety": "IR64",
  "planting_date": "2026-01-15",
  "expected_harvest": "2026-05-15",
  "area": 2.5,
  "status": "growing"
}
```

### Weather
- `GET /api/weather?location=Guntur` - Get weather data
- `POST /api/weather` - Add weather data

**Example - Add Weather Data:**
```json
POST /api/weather
{
  "location": "Guntur, AP",
  "temperature": 32.5,
  "humidity": 65,
  "rainfall": 0,
  "wind_speed": 12.5,
  "weather_condition": "Partly Cloudy"
}
```

### Market Prices
- `GET /api/market-prices?crop_name=Rice` - Get prices
- `GET /api/market-prices?crop_name=Rice&location=Guntur` - Filter by location
- `POST /api/market-prices` - Add price data

**Example - Add Market Price:**
```json
POST /api/market-prices
{
  "crop_name": "Rice",
  "location": "Guntur",
  "price": 1850.00,
  "market_name": "Guntur Agricultural Market"
}
```

### Recommendations
- `POST /api/recommendations/crops` - Get crop recommendations

**Example:**
```json
POST /api/recommendations/crops
{
  "location": "Guntur, AP",
  "soil_type": "loamy"
}
```

## Database Schema

### Users Table
- id, name, email, phone, location, farm_size, created_at

### Crops Table
- id, user_id, crop_name, variety, planting_date, expected_harvest, area, status, created_at

### Weather Data Table
- id, location, temperature, humidity, rainfall, wind_speed, weather_condition, recorded_at

### Market Prices Table
- id, crop_name, location, price, market_name, recorded_at

### Feature Flags Table
- id, name, enabled, description, created_at, updated_at

## Using with Frontend

Make sure your frontend points to the backend URL:

```javascript
const API_URL = 'http://localhost:5000/api';

// Example: Fetch crops
fetch(`${API_URL}/crops?user_id=1`)
  .then(res => res.json())
  .then(data => console.log(data));

// Example: Check feature flag before showing UI
fetch(`${API_URL}/feature-flags/weather_api`)
  .then(res => res.json())
  .then(flag => {
    if (flag.enabled) {
      // Show weather widget
    }
  });
```

## Production Deployment

1. **Use PostgreSQL:**
```bash
DATABASE_URL=postgresql://user:pass@localhost/agri_mithra
```

2. **Set SECRET_KEY:**
```bash
SECRET_KEY=$(python -c 'import secrets; print(secrets.token_hex(32))')
```

3. **Use Production Server:**
```bash
pip install gunicorn
gunicorn -w 4 -b 0.0.0.0:5000 app:app
```

## Feature Flag Best Practices

1. **Gradual Rollouts** - Enable features for testing before full deployment
2. **A/B Testing** - Toggle features for different user groups
3. **Emergency Switches** - Quickly disable problematic features
4. **Dark Launches** - Deploy code with features disabled, enable when ready

## Support

For issues or questions, check the code comments or raise an issue.
